<template>
    <div>
        <h1> List componenti </h1>

<!-- <h3> {{gelenSoz}} </h3>


<p> {{ test() }} </p> -->


<ul class="list-group list-group-horizontal-sm mt-5">
  <li class="list-group-item" v-for="item, index of gelenData" :key="item" >
    
   <button class="btn btn-primary btn-sm">  #{{ item }} <span class="badge badge-light" @click="delet(index)">X</span>   </button>

<!-- <button @click="delet(index)" class="btn btn-danger btn-sm"> Sil</button> -->
  </li>
</ul>


    </div>
</template>




<script>
export default {
    // props : ['gelenSoz'],
    // props : {
    //     gelenSoz : {
    //         type : String,
    //         // default : 'test'
    //     }
    // },

    props : {
        gelenData : {
            type : Array,
        }
        
    },


methods  :{
    // test(){
    //    return this.gelenSoz.split('').reverse().join('');
    // }
    delet(index){
      this.gelenData.splice(index,1);
    },
}


}
</script>


<style scoped>
/* ul{
    display: inline-flex;
}; */

</style>