<script setup>

import List from './components/list.vue'

</script>

<template>
  <div>

<div class="container">
  <div class="row">
    <div class="col-6 offset-3 ">

<form @submit.prevent="add" class="pt-5 d-flex">
<input type="text" class="form-control" v-model="value"/>
<button  type="submit"  class="btn btn-success btn-sm"> Add </button>
</form>

 <hr />
<List :gelenData="arr" />

    </div>
  </div>

  <!-- <button class="btn btn-info" @click="change"> deyis </button> -->

 



</div>

  </div>
</template>

<script>
export default {
  data(){
    return {
      value : "",
      arr : [],
      text : "Salam"
    }
  },

  methods  :{
    add(){
     this.arr.push(this.value);
     this.value = "";
    },

    

    change(){
      this.text = "Sagol"
    }
  }
}
</script>

<style scoped>


</style>